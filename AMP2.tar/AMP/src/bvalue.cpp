#include "bvalue.hpp"

BValue::~BValue(){ }
