//
//  DoubleSymb.cpp
//  Bertini2
//
//  Created by James Collins on 12/9/13.
//  Copyright (c) 2013 James Collins. All rights reserved.
//

#include "DoubleSymb.h"
